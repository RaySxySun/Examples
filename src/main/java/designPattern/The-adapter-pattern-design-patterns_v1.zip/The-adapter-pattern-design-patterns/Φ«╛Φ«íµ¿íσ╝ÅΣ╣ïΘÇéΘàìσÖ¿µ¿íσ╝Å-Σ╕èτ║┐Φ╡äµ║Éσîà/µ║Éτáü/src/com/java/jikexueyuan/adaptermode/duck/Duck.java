package com.java.jikexueyuan.adaptermode.duck;

public interface Duck {
	public void quack();
	public void fly();
}
