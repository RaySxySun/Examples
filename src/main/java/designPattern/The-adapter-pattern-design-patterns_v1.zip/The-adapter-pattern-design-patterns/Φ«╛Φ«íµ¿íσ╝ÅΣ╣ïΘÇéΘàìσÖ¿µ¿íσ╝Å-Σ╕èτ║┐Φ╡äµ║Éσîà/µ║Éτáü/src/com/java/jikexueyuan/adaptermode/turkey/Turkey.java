package com.java.jikexueyuan.adaptermode.turkey;

public interface Turkey {

	public void gobble();
	public void fly();

}
