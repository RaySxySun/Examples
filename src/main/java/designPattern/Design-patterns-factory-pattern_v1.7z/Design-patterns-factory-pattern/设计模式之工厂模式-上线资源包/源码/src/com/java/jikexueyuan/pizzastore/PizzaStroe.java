package com.java.jikexueyuan.pizzastore;



public class PizzaStroe {
	public static void main(String[] args) {
		
		OrderPizza mOrderPizza;
		mOrderPizza=new	OrderPizza();
		
	}

	

}
