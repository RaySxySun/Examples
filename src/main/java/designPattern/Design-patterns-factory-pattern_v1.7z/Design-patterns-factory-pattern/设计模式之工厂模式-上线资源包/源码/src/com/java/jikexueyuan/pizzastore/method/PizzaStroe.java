package com.java.jikexueyuan.pizzastore.method;



public class PizzaStroe {
	public static void main(String[] args) {
		
		OrderPizza mOrderPizza;
		mOrderPizza=new	NYOrderPizza();
		
	}

	

}
