package com.java.jikexueyuan.iteratormode.iterator;

public interface Iterator {
	
	public boolean hasNext();
	public Object next();
	

}
