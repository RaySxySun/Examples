package com.java.jikexueyuan.iteratormode;


public class MainTest {
	public static void main(String[] args) {
	
		Waitress mWaitress=new Waitress();
		
		mWaitress.printMenu();
	}
}
