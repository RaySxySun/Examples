package com.java.jikexueyuan.commandmode.command;

public interface Command {
	public void execute();
	public void undo();
}
